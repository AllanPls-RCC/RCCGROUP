# -*- coding: utf-8 -*-
##########################################################################
#
#   Copyright (c) 2015-Present Webkul Software Pvt. Ltd. (<https://webkul.com/>)
#   See LICENSE file for full copyright and licensing details.
#   License URL : <https://store.webkul.com/license.html/>
#
##########################################################################

from . import traccar_configuration
from . import fleet_vehicle
from . import trip_details

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
